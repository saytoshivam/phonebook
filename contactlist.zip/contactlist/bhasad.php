<html>
<head>
	<title>	</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<section>
		<div class="head">
			<p class="tag" >RM-PHONEBOOK</p>	
		</div>
	</section>	
	<section class="update">
		<table align=center>
		<form action="index.php" method="post">
			<tr>
				<td><input type="number" name="id" class="inputbox"></td>
				<td><input type="submit" name="submit" value="Search" class="button"></td>
			</tr>
		</form>
	</table>
	</section>
	<section class="indexmain">
		<?php
			$names=array();
			$i=0;
			$connect = mysqli_connect("localhost", "root", "", "contact");
			$sql="SELECT *FROM contactinfo";
			$run=mysqli_query($connect,$sql);
			if(mysqli_num_rows($run)<1)
			{
				echo"<h1>No Reccord Found</h1>";
			}
			else
			{
				while($data=mysqli_fetch_assoc($run))
				{
					 $names[$i]=$data['name'];
					 $i++;				
				}
			}
			sort($names);
			 $q=0;
			 $light=0;
		 while($q!=$i)
		 {
		?>
			 <a href="<?php echo $light;?> ">
			 	<select class="frontselect">
			 		<option>
			 			<?php echo $names[$q]; ?>
			 		</option>
		 		</select>
		 	</a>
			<script type="text/javascript">
				var onediv=document.createElement('div');
				onediv.id='<?php echo "$light"?>';
				onediv.class="lightbox";
				onediv.style="height: 300px;width: 55%;position: fixed;background: red;display:block";
				document.getElementsByTagName('body')[0].appendChild(onediv);
			</script>
		 		<a href="#">X</a>
		 			<?php 
		 				$temp=$names[$q];
		 				$sql="SELECT *FROM mobilenumber where name='$temp'";
						$run=mysqli_query($connect,$sql);
						while($data=mysqli_fetch_assoc($run))
						{?>
							<script type="text/javascript">
								onediv.p="<?php echo $data['mobile'] ?> ";
							</script>
							<?php 	
						}
		 			 ?>
		 	</div>
			<?php
			$light++;
		 	$q++;
		}
		?>
	</section>
</body>
</html>
