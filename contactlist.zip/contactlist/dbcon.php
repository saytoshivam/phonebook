<?php 
		$con=mysqli_connect('localhost','root','','sms');

		if($con==false)
			{echo"connection not done";
		?>
			<script>
				alert('Connection not done');
			</script>
			<?php
		}
 ?> 