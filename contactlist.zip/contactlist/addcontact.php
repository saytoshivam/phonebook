<html>
<head>
	<title>	</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="homecss.css">
</head>
<body>
	<section>
		<div class="head">
			<p class="tag" >RM-PHONEBOOK</p>	
		</div>
	</section>	
	 <section class="insert">
      		<form method="post" enctype="multipart/form-data" class="maintable" id="add_name">
      			<title><h2>Add new Contact</h2> </title>
					Name:<br>
					<input type="text" name="name" required class="inputmain"><br>
					DOB:<br>
					<input type="date" name="dob" required class="inputmain" ><br>
					Mobile Number:<br>
					<table align=center  id="dynamic_field">
						<tr >
							<td><input type="number" name="mobile[]" id="mobile" required class="inputbox"></td>
							<td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>
						</tr>
					</table>
					Email:
					<table align=center  id="dynamic_field1">
						<tr >
							<td><input type="email" name="email[]" id="email" required class="inputbox"></td>
							<td><button type="button" name="add1" id="add1" class="btn btn-success">Add More</button></td>
						</tr>
					</table>
						<tr><td><input type="button" name="submit" id="submit" value="Save" required class="button inputmain" style="margin-top:5%;"></td></tr>	
			</form>
		</section>	
		<section>
		<a href="index.php">	<input type="submit" name="submit" value="View Contacts" class="button shivam"></a>
	</section>	
</body>
</html>
<script>
$(document).ready(function(){
	var i=1;
	$('#add').click(function(){
		i++;
		$('#dynamic_field').append('</br><tr id="row'+i+'"><td><input type="number" name="mobile[]" class="inputbox"/></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
	});
	
	$(document).on('click', '.btn_remove', function(){
		var button_id = $(this).attr("id"); 
		$('#row'+button_id+'').remove();
	});

	var j=1;
	$('#add1').click(function(){
		j++;
		$('#dynamic_field1').append('</br><tr id="row1'+j+'"><td><input type="email" name="email[]" class="inputbox"/></td><td><button type="button" name="remove" id="'+j+'" class="btn btn-danger btn_remove">X</button></td></tr>');
	});
	
	$(document).on('click', '.btn_remove', function(){
		var button_id = $(this).attr("id"); 
		$('#row1'+button_id+'').remove();
	});
	
	$('#submit').click(function(){		
		$.ajax({
			url:"mobile.php",
			method:"POST",
			data:$('#add_name').serialize(),
			success:function(data)
			{
				alert(data);
				$('#add_name')[0].reset();
			}
		});
	});
	
});
</script>
