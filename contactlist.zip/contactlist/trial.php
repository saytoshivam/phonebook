<html>
<head>
	<title>dynamic div</title>
</head>
<body>
	<?php
	$i=0;
	while($i!=4)
	{
	?>
		<script type="text/javascript">
	var onediv=document.createElement('div');
	onediv.id='<?php echo "$i"?>';
	onediv.style="height: 300px;width: 55%;position: fixed;background: red;display:block";
	document.getElementsByTagName('body')[0].appendChild(onediv);
	</script>

	<?php
	$i++;
	}
	?>
</body>
</html>