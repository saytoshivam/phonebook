<?php
	$sid=$_GET['sid'];
	$con = mysqli_connect("localhost", "root", "", "contact");
	$sql="SELECT *FROM mobilenumber  WHERE name='$sid'";
	$sql1="SELECT *FROM emailaddress  WHERE name='$sid'";
	$run=mysqli_query($con,$sql);
	$run1=mysqli_query($con,$sql1);
?>

 <html>
 <head>
 	<title></title>
 	<link rel="stylesheet" href="logo.css" type="text/css">
 	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="homecss.css">
 </head>
 <body>
     <div class="sign" style="margin-top:9vh">
             <span class="fast-flicker">RM-PHONE</span><span class="flicker">BOOK</span>
       </div>
 	<div class="insert">
 		<table align=center width="80%" border="1" style="margin-top:5vh;">
		<tr style="background-color:black;color:white">
			<th>Name</th>
			<th>Mobile num</th>
			<th>Email</th>
			<th>Remove</th>
		</tr>
 		<form method="post" action="deleteform.php" enctype="multipart/form-data">
			<tr>
				<td><?php echo $sid;?></td>
				<td>
				<?php
					while($data=mysqli_fetch_assoc($run))
					{
					?>
					<?php echo $data['mobile'];?>
					   </br>
						<?php  
					}
				?>
				</td>
				<td>
				<?php
					while($data1=mysqli_fetch_assoc($run1))
					{
					?>
							<?php echo $data1['email'];?>
							</br>
						<?php  
					}
				?>
				</td>
				<td>
					<a href="deleteform.php?sid=<?php echo $sid; ?>">Delete</a>
				</td>
			</tr>	
		</table>	
	</form>
 	</div>
 	<section>
		<a href="index.php">	<input type="submit" name="submit" value="View Contacts" class="button shivam"></a>
	</section>
 </body>
 </html>