<?php 
		$con = mysqli_connect("localhost", "root", "", "contact");
		$id=$_REQUEST['sid'];
		
		$qry="DELETE FROM mobilenumber WHERE name=$id";
		$run=mysqli_query($con,$qry);
		if($run==true)
		{
			?>
			<script>
				alert('Data Deleted Successfully');
				window.open('indexhelper.php','_self');
			</script>
			<?php
		}
 ?>