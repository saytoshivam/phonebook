<html>
<head>
	<title>RM-PHONEBOOK</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="homecss.css">
	<link rel="stylesheet" href="logo.css" type="text/css">
</head>
<body>
	<section>
		<div class="head">
			<p class="tag" >RM-PHONEBOOK</p>	
		</div>
	</section>	
	<div class="sign" style="margin-top:9vh">
             <span class="fast-flicker">RM-PHONE</span><span class="flicker">BOOK</span>
       </div>
	<section class="update">
		<table align=center>
		<form action="index.php" method="post">
			<tr>
				<td>search by name</td>
				<td><input type="text" name="cname"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Search" class="button"></td>
			</tr>
		</form>
	</table>
	</section>
	<table align=center width="80%" border="1" style="margin-top:5vh; font-size:3rem;">
		<tr style="background-color:black;color:white;">
			<th>Sr. No</th>
			<th>Name</th>
			<th>View</th>
			<th>Edit</th>
		</tr>
	<?php
			$con = mysqli_connect("localhost", "root", "", "contact");
			$name=$_POST['cname'];
			$sql="SELECT *FROM contactinfo  WHERE  name LIKE '%$name%'";
			$run=mysqli_query($con,$sql);
			if(mysqli_num_rows($run)<1)
			{
				echo"<tr><td colspan='10'>No Reccord Found</td></tr>";
			}
			else
			{
				$count=0;
				while($data=mysqli_fetch_assoc($run))
				{
					$count++;
					?>
						<tr>
							<td><?php echo $count; ?></td>
							<td><?php echo  $data['name']; ?></td>
							<td><a href="indexhelper.php?sid=<?php echo $data['name']; ?>">View</a></td>
							<td><a href="updateform.php?sid=<?php echo $data['name']; ?>">Update</a></td>
						</tr>
					<?php
				}
			}
	?>
	</table>
	<section>
		<a href="addcontact.php">	<input type="submit" name="submit" value="ADD CONTACT" class="button shivam"></a>
	</section>
</body>
</html>