<?php
$connect = mysqli_connect("localhost", "root", "", "contact");
$number = count($_POST["mobile"]);
$name=$_POST['name'];
$dob=$_POST['dob'];
$mobile=$_POST['mobile'];
$qry="INSERT INTO contactinfo(name,date) VALUES ('$name','$dob')";

$run=mysqli_query($connect,$qry);
if($number > 1)
{
	for($i=0; $i<$number; $i++)
	{
		if(trim($_POST["mobile"][$i] != ''))
		{
			$sql = "INSERT INTO mobilenumber(name,mobile) VALUES('$name','".mysqli_real_escape_string($connect, $_POST["mobile"][$i])."')";
			mysqli_query($connect, $sql);
		}
	}
}
$number2 = count($_POST["email"]);
if($number2 > 1)
{
	for($i=0; $i<$number2; $i++)
	{
		if(trim($_POST["email"][$i] != ''))
		{
			$sql1 = "INSERT INTO emailaddress(name,email) VALUES('$name','".mysqli_real_escape_string($connect, $_POST["email"][$i])."')";
			mysqli_query($connect, $sql1);
		}
	}
	echo "Data Inserted";
}
else
{
	echo "Please Enter data accurately";
}
?>