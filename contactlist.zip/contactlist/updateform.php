<?php
	$con = mysqli_connect("localhost", "root", "", "contact");
	$sid=$_GET['sid'];

	$sql="SELECT *FROM mobilenumber  WHERE name='$sid'";
	$run=mysqli_query($con,$sql);
	$data=mysqli_fetch_assoc($run);

	$sql1="SELECT *FROM emailaddress  WHERE name='$sid'";
	$run1=mysqli_query($con,$sql1);
	$data1=mysqli_fetch_assoc($run1);


?>

 <html>
 <head>
 	<title></title>
 	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="homecss.css">
	<link rel="stylesheet" href="logo.css" type="text/css">
 </head>
 <body>
     <div class="sign" style="margin-top:9vh">
             <span class="fast-flicker">ASK</span><span class="flicker">.com</span>
       </div>
 	<div class="insert">
 		<form method="post" action="updatedata.php" enctype="multipart/form-data">
		<table>
			<tr>
				<td>name</td>
				<td><input type="text" name="name" value="<?php echo $data['name'];?>"  required></td>
			</tr>		
			<tr>
				<td>mobile number</td>
				<td><input type="number" name="mob" value="<?php echo $data['mobile'];?>"  required></td>
			</tr>	
			<tr>
				<td>email</td>
				<td><input type="email" name="email" value="<?php echo $data1['email'];?>" required></td>
			</tr>	
				<tr><td><input type="submit" name="submit" value="Update" required class="button"></td></tr>	
		</table>	
	</form>
 	</div>
 	<section>
		<a href="index.php">	<input type="submit" name="submit" value="View Contacts" class="button shivam"></a>
	</section>	
 
 </body>
 </html>